package com.app.shubhamjhunjhunwala.popularmovies;

import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.JSONUtils;
import com.app.shubhamjhunjhunwala.popularmovies.Utils.NetworkUtils;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    public RecyclerView recyclerView;

    public String response = null;
    public Movie[] movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);

        URL url = NetworkUtils.buildTopRatedURL();

        Log.d("Built URL", url.toString());

        AsyncTask<URL, Void, String> asyncTask = new AsyncTask<URL, Void, String>() {

            @Override
            protected String doInBackground(URL... urls) {
                try {
                    response = NetworkUtils.getResponseFromHTTPUrl(urls[0]);
                    movies = JSONUtils.getDataFromJSONResponce(response);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (response != null) {
                    return response;
                }

                return null;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                Log.d("JSON Responce", response);

                for (int i = 0, n = movies.length; i < n; i++) {
                    Log.d("Data at " + String.valueOf(i + 1), movies[i].getTitle());
                }

                attachAdapter();
            }
        };

        asyncTask.execute(url);
    }

    public void attachAdapter() {
        StaggeredGridLayoutManager staggeredGridLayoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);

        recyclerView.setLayoutManager(staggeredGridLayoutManager);

        recyclerView.setHasFixedSize(true);

        MoviesAdapter moviesAdapter = new MoviesAdapter(movies);

        recyclerView.setAdapter(moviesAdapter);
    }
}

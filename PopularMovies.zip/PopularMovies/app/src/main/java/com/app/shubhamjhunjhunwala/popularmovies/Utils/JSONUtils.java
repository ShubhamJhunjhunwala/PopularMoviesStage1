package com.app.shubhamjhunjhunwala.popularmovies.Utils;

import com.app.shubhamjhunjhunwala.popularmovies.Objects.Movie;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by shubham on 09/01/18.
 */

public class JSONUtils {

    public static Movie[] getDataFromJSONResponce(String JSONResponce) throws JSONException {

        JSONObject responce = new JSONObject(JSONResponce);

        JSONArray results = responce.getJSONArray("results");

        Movie[] movies = new Movie[results.length()];

        for (int i = 0, l = results.length(); i < l; i++) {
            JSONObject currentMovieObject = results.getJSONObject(i);

            movies[i] = new Movie(currentMovieObject.getString("title"),
                                    "http://image.tmdb.org/t/p/original/" + currentMovieObject.getString("poster_path"),
                                    currentMovieObject.getString("overview"),
                                    currentMovieObject.getString("vote_average"),
                                    currentMovieObject.getString("release_date"));
        }

        return movies;
    }
}

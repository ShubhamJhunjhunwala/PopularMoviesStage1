package com.app.shubhamjhunjhunwala.popularmovies.Utils;

import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
 * Created by shubham on 09/01/18.
 */

public class NetworkUtils {
    public static String BASE_URL_TOP_RATED = "https://api.themoviedb.org/3/movie/top_rated";

    public static String BASE_URL_MOST_POPULAR = "https://api.themoviedb.org/3/movie/popular";

    public static String API_KEY_PARAM = "api_key";

    public static String LANGUAGE_PARAM = "language";

    public static String LANGUAGE = "en-US";

    public static String accountID = "b565f42fdadf757c89f47adc3a184092";

    public static URL buildTopRatedURL() {
        Uri uri = Uri.parse(BASE_URL_TOP_RATED)
                .buildUpon()
                .appendQueryParameter(API_KEY_PARAM, accountID)
                .appendQueryParameter(LANGUAGE_PARAM, LANGUAGE)
                .build();

        URL url = null;

        try {
            url = new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return url;
    }

    public static String getResponseFromHTTPUrl(URL url) throws IOException {
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

        try {
            InputStream inputStream = httpURLConnection.getInputStream();

            Scanner scanner = new Scanner(inputStream);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            httpURLConnection.disconnect();
        }
    }
}

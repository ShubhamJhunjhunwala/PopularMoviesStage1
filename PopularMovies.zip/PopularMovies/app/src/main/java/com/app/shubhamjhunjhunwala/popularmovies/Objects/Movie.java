package com.app.shubhamjhunjhunwala.popularmovies.Objects;

/**
 * Created by shubham on 09/01/18.
 */

public class Movie {

    public String title;
    public String imageURL;
    public String synopsis;
    public String voteAverage;
    public String releaseDate;

    public Movie(String title, String imageURL, String synopsis, String voteAverage, String releaseDate) {
        this.title = title;
        this.imageURL = imageURL;
        this.synopsis = synopsis;
        this.voteAverage = voteAverage;
        this.releaseDate = releaseDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getVoteAverage() {
        return voteAverage;
    }

    public void setVoteAverage(String voteAverage) {
        this.voteAverage = voteAverage;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }
}
